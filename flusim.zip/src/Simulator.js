import React from 'react';

class Simulator extends React.Component {
  render() {
    return (
      <div>
        <h1>Flu Simulator</h1>
        {/* Simulator code will go here */}
        
      </div>
    );
  }
}

export default Simulator;
